package br.digitalhouse.projetointegrador.clinica.domain.entity;

public enum EspecialdiadeEnum {
    ORTODONTISTA, ODONTOPEDIATRA, CLINICO_GERAL, IMPLANTODENTISTA
}

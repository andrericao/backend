public class Main {
    public static void main(String[] args) {

        Nave nave1 = new Nave(10, 20,  'N',  100.0, 1000);


        System.out.println(nave1.toString());
    }

}
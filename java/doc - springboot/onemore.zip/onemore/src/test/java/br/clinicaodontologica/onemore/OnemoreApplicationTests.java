package br.clinicaodontologica.onemore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnemoreApplicationTests {

	@Test
	void contextLoads() {
	}

}

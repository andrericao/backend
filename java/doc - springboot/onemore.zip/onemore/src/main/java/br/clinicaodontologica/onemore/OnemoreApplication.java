package br.clinicaodontologica.onemore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnemoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnemoreApplication.class, args);
	}

}
